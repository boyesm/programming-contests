file = open("DATA41.txt", "r")
input = file.readline()
